﻿namespace HotelBookingApp.Models
{
    public class ClientModel
    {
        public int ClientId { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}