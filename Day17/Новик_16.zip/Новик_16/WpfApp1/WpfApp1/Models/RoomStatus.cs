﻿namespace HotelBookingApp.Models
{
    public enum RoomStatus
    {
        Available,
        Occupied,
        Maintenance
    }
}