﻿using System.Windows.Controls;

namespace HotelBookingApp.Views
{
    public partial class ChatView : UserControl
    {
        public ChatView()
        {
            InitializeComponent();
        }
    }
}