﻿namespace WpfApp1.Models
{
    public enum RoomStatus
    {
        Available,
        Occupied,
        Maintenance,
    }
}