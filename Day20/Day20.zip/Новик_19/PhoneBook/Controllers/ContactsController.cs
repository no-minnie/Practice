﻿using Microsoft.AspNetCore.Mvc;
using PhoneBook.Models;
using PhoneBook.Services;

namespace PhoneBook.Controllers
{
    public class ContactsController : Controller
    {
        private readonly IContactRepository _contactRepository;

        public ContactsController(IContactRepository contactRepository)
        {
            _contactRepository = contactRepository;
        }

        [HttpGet]
        public IActionResult Index(string searchTerm)
        {
            IEnumerable<Contact> contacts;
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                contacts = _contactRepository.SearchContacts(searchTerm);
                ViewData["SearchTerm"] = searchTerm;
            }
            else
            {
                contacts = _contactRepository.GetAllContacts();
            }

            if (ViewData["ContactFormData"] == null)
            {
                ViewData["ContactFormData"] = new Contact();
            }

            return View(contacts);
        }

        [HttpGet("Contacts/Search/{name}")]
        public IActionResult Search(string name)
        {
            return RedirectToAction(nameof(Index), new { searchTerm = name });
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind(Prefix = "contactFormData")] Contact contact)
        {
            if (ModelState.IsValid)
            {
                _contactRepository.AddContact(contact);
                return RedirectToAction(nameof(Index)); 
            }

            var allContacts = _contactRepository.GetAllContacts();
            ViewData["ContactFormData"] = contact; 
            return View("Index", allContacts); 
        }
    }
}