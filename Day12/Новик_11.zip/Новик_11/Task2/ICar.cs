﻿namespace Task2
{
    public interface ICar
    {
        string GetFeatures();
        double GetPrice();
    }
}