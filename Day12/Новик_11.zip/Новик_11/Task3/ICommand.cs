﻿namespace Task3
{
    public interface ICommand
    {
        void Execute();
    }
}