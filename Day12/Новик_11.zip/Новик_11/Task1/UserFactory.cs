﻿namespace Task1
{
    public abstract class UserFactory
    {
        public abstract IUser CreateUser();
    }
}