﻿namespace Task1
{
    public interface IUser
    {
        string[] GetPermissions();
    }
}