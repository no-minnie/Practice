﻿using System.Windows;

namespace HotelBookingApp
{
    public partial class App : Application
    {

    }
}