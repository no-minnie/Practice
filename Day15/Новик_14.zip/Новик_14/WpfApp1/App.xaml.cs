﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp1
{
    public partial class App : Application
    {
    }
}